declare module '*.svg' {
  import React from 'react';
  import {SvgProps} from 'react-native-svg';
  const content: React.FC<SvgProps>;
  export default content;
}
declare module '*.jpg' {
  const value: any;
  export default value;
}
declare module '*.png' {
  const value: string;
  export default value;
}
